from .aspp import ASPP
from .deeplabv3 import DeepLabV3Decoder
from .deeplabv3plus import DeepLabV3PlusDecoder
from .panoptic_deeplab import PanopticDeepLabDecoder
from .instance_deeplab import InstanceDeepLabDecoder
