from .resnet import *
from .mobilenet import *
from .mnasnet import *
from .hrnet import *
from .xception import *
from .nvidia_sem.ocrnet import HRNet_Mscale