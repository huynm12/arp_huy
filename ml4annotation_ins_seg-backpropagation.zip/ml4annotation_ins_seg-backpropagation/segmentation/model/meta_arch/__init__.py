from .deeplabv3 import DeepLabV3
from .deeplabv3plus import DeepLabV3Plus
from .panoptic_deeplab import PanopticDeepLab
from .instance_deeplab import InstanceDeepLab
from .vinai_panoptic_deeplab import VinAIPanopticDeepLab
