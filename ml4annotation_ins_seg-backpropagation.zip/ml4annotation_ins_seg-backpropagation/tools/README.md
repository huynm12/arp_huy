## Introduction
This directory contains training and evaluation code for my original implementation which will be deprecated.

## Installation

See [INSTALL.md](/tools/docs/INSTALL.md).

## Quick Start

See [GETTING_STARTED.md](/tools/docs/GETTING_STARTED.md).

## Model Zoo

See [MODEL_ZOO.md](/tools/docs/MODEL_ZOO.md).